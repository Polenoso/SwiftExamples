//
//  Meal+CoreDataProperties.swift
//  FoodTrackerTutorial
//
//  Created by Aitor Pagán on 25/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Meal {

    @NSManaged var name: String?
    @NSManaged var photo: NSData?
    @NSManaged var rating: NSNumber?

}
