//
//  Meal.swift
//  FoodTrackerTutorial
//
//  Created by Aitor Pagán on 20/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class Meal: NSManagedObject{
    //MARK: Properties
    
    let managedContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext

    
    // MARK: Types
    
    struct PropertyKey {
        static let nameKey = "name"
        static let photoKey = "photo"
        static let ratingKey = "rating"
    }
    
    //MARK: Initialize
    
    
    func saveMeal(name: String, photo: UIImage, rating: Int){
        
        let meal = NSEntityDescription.insertNewObjectForEntityForName("Meal", inManagedObjectContext: managedContext) as! Meal
        
        meal.name = name
        meal.photo = photo.valueForKey("image") as? NSData
        meal.rating = rating
        
        try! managedContext.save()
        
    }
    
    func save(){
        let meal = NSEntityDescription.insertNewObjectForEntityForName("Meal", inManagedObjectContext: managedContext) as! Meal
        
        meal.name = self.name
        //
        meal.rating = self.rating
        
        try! managedContext.save()
        
    }
    
    func deleteMeal(meal: Meal){
        
        let meal = NSEntityDescription.insertNewObjectForEntityForName("Meal", inManagedObjectContext: managedContext) as! Meal
        
        managedObjectContext?.delete(meal)
        
    }
    

    
    // MARK: Archiving Paths
    
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("meals")
    

}
