//
//  ViewController.swift
//  UrlRequest
//
//  Created by Aitor Pagán on 25/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {

   
    
    @IBOutlet weak var textField: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        getRequest()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func getRequest() {
        
        let url = "http://localhost:8080/WebServiceExample/webresources/model.product"
        let url2 = NSURL(string: url)
        let session = NSURLSession.sharedSession()
        let request = NSURLRequest(URL: url2!)
        
        
        
        session.dataTaskWithRequest(request) { (data, response, error) -> Void in
            
            // Handle incoming data like you would in synchronous request
            let reply = NSString(data: data!, encoding: NSUTF8StringEncoding)
            if((reply) != nil){
                //print (reply)
                
                dispatch_sync(dispatch_get_main_queue()) {
                    let replyJSON = try! NSJSONSerialization.JSONObjectWithData(data!, options: .MutableContainers)
                    var tito: String = ""
                    var i=0
                    
                    
                    
                    for (i=0; i<replyJSON.count;i++){
                        tito += replyJSON[i]["description"] as! String + "\n"
                    }
                    self.textField.text = tito
                    self.view.reloadInputViews() // this results in all of the `UITableViewDataSource` methods to be called
                    
                }
                
            }
            }.resume()
        
        
        let sendJSON = ["available":"TRUE","description":"Identity Server","manufacturerId":["addressline1":"5 81st Street","addressline2":"Suite 100","city":"Mountain View","email":"happysearching@example.com","fax":"408-555-0103","manufacturerId":19985678,"name":"Happy End Searching","phone":"650-555-0102","rep":"John Snow","state":"CA","zip":"94043"],"markup":8.25,"productCode":["description":"Software","discountCode":"M","prodCode":"SW"],"productId":190291,"purchaseCost":1095.00,"quantityOnHand":800000]
        
        let session2 = NSURLSession.sharedSession()
        let request2 = NSMutableURLRequest(URL: NSURL(string: "http://localhost:8080/WebServiceExample/webresources/model.product")!)
        request2.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request2.addValue("application/json", forHTTPHeaderField: "Accept")
        request2.HTTPMethod = "POST"
        
        
        
        let sendData = try! NSJSONSerialization.dataWithJSONObject(sendJSON, options: NSJSONWritingOptions())
        
        request2.HTTPBody = sendData
        
        session2.dataTaskWithRequest(request2){(data,response,error)in
            let httpResponse = response as? NSHTTPURLResponse
            print(httpResponse?.statusCode)
        }.resume()
        
        
    
    
    }
 
    
}

