//
//  main.swift
//  HolaMundoSwift
//
//  Created by Aitor Pagán on 19/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

import Foundation

let params = Process.arguments;

let sortedparams = params.sort();

let setparams = Set(sortedparams);

print(setparams.reverse());









