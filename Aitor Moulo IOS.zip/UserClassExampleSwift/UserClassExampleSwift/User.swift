//
//  User.swift
//  UserClassExampleSwift
//
//  Created by Aitor Pagán on 19/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//


import Foundation

class User: Hashable, Equatable{
    
    var nombre:String
    var apellido:String
    var hashValue:Int
    
    init(nombre:String, apellido:String){
        self.nombre = nombre
        self.apellido = apellido
        self.hashValue = nombre.hashValue / apellido.hashValue
        
    }
    
    func isEqual(other: User?) -> Bool {
        if (self.nombre.isEqual(other!.apellido)){
            return self.apellido.isEqual(other?.apellido)
        }else{
            return self.nombre.isEqual(other?.nombre)
        }
    }
    
    func compare(other:User?) -> NSComparisonResult{
        if(self.nombre.isEqual(other?.nombre)){
            return self.apellido.compare((other?.apellido)! as String)
        }else{
            return self.nombre.compare((other?.nombre)! as String)
        }
    }
    

}

func ==(lhs: User, rhs: User) -> Bool{
    
    return lhs.nombre == rhs.nombre && lhs.apellido == rhs.apellido
    
}


