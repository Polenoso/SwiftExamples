//
//  main.swift
//  UserClassExampleSwift
//
//  Created by Aitor Pagán on 19/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

import Foundation

var usuario1 = User(nombre:"Pepe", apellido:"Lopez")
var usuario2 = User(nombre:"Alfredo", apellido:"Lopez")
var usuario3 = User(nombre:"Jose", apellido:"Lopez")
var usuario4 = User(nombre:"Jose", apellido:"Lopez")


let userarray = Array([usuario1,usuario2,usuario3,usuario4])

let setusers = Set(userarray)


for a in setusers.sort ({(B1: User, B2: User) -> Bool in
    
    return B1.nombre < B2.nombre
    
})
{
    print(a.nombre," ",a.apellido)
}







