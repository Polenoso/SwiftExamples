//
//  User.h
//  UserClassExample
//
//  Created by Aitor Pagán on 18/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (readwrite) NSString *nombre;
@property (readwrite) NSString *apellido;

- (NSComparisonResult)compare:(id)object1;

- (BOOL)isEqual:(id)object1;

@end
