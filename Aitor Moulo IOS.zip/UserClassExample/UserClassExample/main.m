//
//  main.m
//  UserClassExample
//
//  Created by Aitor Pagán on 18/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        User *usuario1 = [[User alloc]init];
        usuario1.nombre = @"Pepe";
        usuario1.apellido = @"Lopez";
        User *usuario2 = [[User alloc]init];
        usuario2.nombre = @"Auan";
        usuario2.apellido = @"Aopez";
        User *usuario3 = [[User alloc]init];
        usuario3.nombre = @"Luan";
        usuario3.apellido = @"Lopez";
        User *usuario4 = [[User alloc]init];
        usuario4.nombre = @"Luan";
        usuario4.apellido = @"Lopez";
        NSArray *usarr = @[usuario1,usuario2,usuario3,usuario4];

        NSArray *sortedusers = [usarr sortedArrayUsingSelector:@selector(compare:)];
        NSSet *setusers = [[NSSet alloc] initWithArray:sortedusers];
        NSEnumerator *usenum = [setusers objectEnumerator];
        id cont;
        while (cont = [usenum nextObject]){
            printf("%s %s\n",[[cont nombre]UTF8String], [[cont apellido]UTF8String]);
        }
        
        
    }
    return 0;
}
