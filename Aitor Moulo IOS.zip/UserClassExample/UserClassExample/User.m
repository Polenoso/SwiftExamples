//
//  User.m
//  UserClassExample
//
//  Created by Aitor Pagán on 18/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize nombre;
@synthesize apellido;

- (NSComparisonResult) compare:(id)object1 {
    if ([[self nombre] isEqual:[object1 nombre]]){
        return [[self apellido] compare: [object1 apellido]];
    }else{
    return [[self nombre] compare:[object1 nombre]];
    }
    
}

- (BOOL) isEqual:(id)object {
    return [[self nombre] isEqual:[object nombre]] && [[self apellido] isEqual:[object apellido]];
}

-(NSUInteger)hash{
    return [self.nombre hash]%[self.apellido hash];
}

@end
