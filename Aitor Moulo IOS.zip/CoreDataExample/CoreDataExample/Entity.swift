//
//  Entity.swift
//  CoreDataExample
//
//  Created by Aitor Pagán on 25/1/16.
//  Copyright © 2016 Aitor Pagán. All rights reserved.
//

import Foundation
import CoreData


class Entity: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
